# Change Log

## 0.2.1 — Feb 17, 2021
- Fix actions not running. This requires VS Code 1.54+. There is not a good approach to backporting the fix to work on older versions of VS Code.

## 0.2.0 — March 7, 2019
- Add fix all in folder.

## 0.0.3 — July 11, 2018
- Execute actions one at a time.

## 0.0.1 — July 11, 2018
- Initial release